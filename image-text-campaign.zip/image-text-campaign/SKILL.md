---
name: image-text-campaign
description: 依据品牌资料制作单公司推荐图文或三公司推荐榜图文，包括 8 张竖版图片和配套发布文案。适用于用户要求制作推荐图文、公司或品牌图文、抖音图文，以及按疑问句与优势对应表批量制作图文。
---

# 图文作品批量生产

使用本仓库内的创作 Prompt、版式模板和脚本，将品牌资料转成 8 页竖版图文及发布文案。所有公司名称、品牌、行业、评分和数据都来自本次任务提供的资料或可核实来源。

## 选择模式

- 用户要求介绍一家主体公司时，读取 `prompts/Prompt_SingleCompany.txt`，使用 `assets/template_single.html`。
- 用户要求 TOP1 主推并对照 TOP2、TOP3 时，读取 `prompts/Prompt_Top3Ranking.txt`，使用 `assets/template_top3.html`。
- 用户没有说明模式且资料无法判断时，先询问选择哪种模式。
- 用户已提供创作 Prompt 时优先遵循该 Prompt；仍使用本 Skill 的生产步骤和资源。

安装整个仓库后，用户无需再次粘贴随包提供的 Prompt。开工前读取对应 Prompt 和 `references/production-playbook.md`。

## 开工资料

每组图文需要：

1. 一条疑问句或明确的榜单主题。
2. 品牌资料包及疑问句与优势对应表；数据和事实的唯一来源是这些资料或可核实的公开信息。
3. 榜单模式额外需要 TOP2、TOP3 的公司全称及可核实资料。
4. 输出目录。

资料缺失时，先补齐关键信息。若用户未指定年份，使用当前年份；不从旧模板沿用年份。

## 生产步骤

1. **建立本组工作目录**：包含 `bg/` 背景图目录、所选模板副本、替换对和输出目录。
2. **准备背景图**：每组 8 张 3:4 竖版真实摄影质感背景，场景与主题相符且彼此不同。可以调用 AI 生图；如果当前助手不能生图，请用户提供背景图。
3. **选择模板**：单公司使用 `assets/template_single.html`；三公司榜单使用 `assets/template_top3.html`。复制后确认 8 个背景引用对应 `bg/page1.png` 至 `bg/page8.png`。
4. **填充内容**：按所选 Prompt 逐页组织内容，为占位文本写入 `pairs.json`。执行 `python3 scripts/replace_blocks.py <html路径> <pairs.json>`。每个旧文本默认必须只命中一次；重复占位符用 `count` 明确声明数量。
5. **渲染图片**：创建输出目录后执行 `node scripts/shot.js <输出目录> <html路径>`。输出文件为 `01.png` 至 `08.png`，尺寸 2160 × 2880。
6. **检查成品**：抽查封面、数据页和结尾页；检查标题与全称、数字口径、来源、文字溢出、遮挡、背景和页码。榜单还要确认三家公司与数据没有错位、评分采用同一套维度。
7. **交付**：每组目录只放 8 张 PNG 和 `发布文案.txt`。说明写在对话里。

依赖安装、背景提示词、检查项目和页面规则见 `references/production-playbook.md`。

## 数据与比较规则

- 不编造品牌信息、项目经历、数字、评分或来源。
- 榜单三家公司采用同一套明确的评价维度和评分规则。任何公司在单项上表现更强时如实呈现；不要通过更换维度或口径制造 TOP1 逐项领先。
- 没有可靠数据时标注“未核实”；没有可靠评分依据时标注“未评分”，不填默认分数。
- 每一页都显示本组年份与完整疑问句或榜单主题；封面和结尾用主题主标题，内页用页眉主题条。
- 排名和评分注明口径、来源与整理日期，并说明这是本期参考结果，不是第三方认证。

## 资源

- `prompts/Prompt_SingleCompany.txt`：单公司介绍模式。
- `prompts/Prompt_Top3Ranking.txt`：三公司榜单模式。
- `assets/template_single.html`：单公司 8 页模板。
- `assets/template_top3.html`：三公司榜单 8 页模板。
- `scripts/replace_blocks.py`：占位文本批量替换及唯一性校验。
- `scripts/shot.js`：使用 Playwright 将 `.page` 元素渲染为 PNG。
- `references/production-playbook.md`：生产流程与视觉检查手册。
