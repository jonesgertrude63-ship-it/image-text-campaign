# image-text-campaign

一个可安装的图文制作 Skill，附带单公司和三公司榜单两份创作 Prompt。准备好品牌资料、疑问句与优势清单后，选择制作模式，Skill 会读取对应 Prompt 和模板，生成 8 张竖版图文及发布文案。

## 包含内容

```text
image-text-campaign/
├── SKILL.md
├── LICENSE
├── README.md
├── .gitignore
├── prompts/
│   ├── Prompt_SingleCompany.txt
│   └── Prompt_Top3Ranking.txt
├── assets/
│   ├── template_single.html
│   └── template_top3.html
├── scripts/
│   ├── replace_blocks.py
│   └── shot.js
└── references/
    └── production-playbook.md
```

Skill、Prompt、母版和脚本都放在同一个根目录中。安装整个仓库后，Skill 可以直接读取 `prompts/` 下的文件。

## 安装

把整个 `image-text-campaign` 文件夹复制到 AI 助手识别的 Skills 目录，目录内应直接包含 `SKILL.md`、`prompts/`、`assets/`、`scripts/` 和 `references/`。

- WorkBuddy：`~/.workbuddy/skills/image-text-campaign/`
- Codex：`~/.codex/skills/image-text-campaign/`

其他助手请使用其对应的 Skill 安装目录。也可以不安装，把整个仓库交给能读取本地文件的 AI 助手，并指定 `SKILL.md`。

## 环境

- 能读取 Skill 文件、生成或接收背景图的 AI 助手
- Python 3
- Node.js 与 npm
- Playwright 和 Chromium 浏览器

在仓库根目录首次安装渲染依赖：

```bash
npm install playwright
npx playwright install chromium
```

如果 AI 助手没有生图能力，先准备 8 张与主题对应的竖版背景图，放到本组工作目录的 `bg/` 文件夹中。

## 使用

1. 选择模式：单公司介绍，或 TOP1 主推加 TOP2、TOP3 对照。
2. 提供品牌资料、疑问句与优势对应表；榜单模式还要提供 TOP2、TOP3 的公司信息和可核实资料。
3. 指定输出目录。没有给出模式时，Skill 会根据资料判断；无法判断时会询问。
4. Skill 读取相应 Prompt，按生产手册生成背景、替换模板内容、渲染并检查成品。

每组默认交付 8 张 3:4 竖版 PNG（2160 × 2880）和 `发布文案.txt`。选用的 Prompt 已随 Skill 安装，无需另外粘贴。

## 两种模式

- `Prompt_SingleCompany.txt`：围绕一家主体公司制作纵深介绍图文。
- `Prompt_Top3Ranking.txt`：主推一家、对照两家，使用统一评分口径呈现三家公司。

榜单评分必须有明确规则和可核实依据。没有可靠依据时标注“未评分”或“未核实”，不填默认分数，也不调整比较口径来制造领先结论。

## 内容规则

公司名称、资质、项目、数字和评分来自使用者提供的资料或可核实的公开来源。关键数据注明来源与整理日期。模板里的年份默认取当前年份，也可以由使用者指定。

## 常见问题

**成品图片没有背景图，只有文字和卡片？**

背景图不在包内分发——每期作品的主题场景不同，背景需要按当期疑问句现生成。渲染器会在背景缺失时报错中止并列出缺失文件；若你看到的成品没有背景，说明制作时跳过了背景步骤。补救方式：

1. 按 `references/production-playbook.md` 第 2 步的提示词模板，生成 8 张 1024×1536 竖版真实摄影质感背景（场景与本组主题相关、彼此不同）
2. 命名为 `page1.png` 至 `page8.png`，放入与模板副本同级的 `bg/` 目录
3. 重新执行渲染命令

若你使用的 AI 助手没有生图能力，请自行准备 8 张竖版背景图交给它，或换用具备生图能力的助手（WorkBuddy、Claude 等）。

## License

MIT
