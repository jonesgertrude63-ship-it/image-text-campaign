# 图文作品生产手册

## 1. 选择模式与资料

- 单公司介绍：读取 `prompts/Prompt_SingleCompany.txt`，使用 `assets/template_single.html`。
- 三公司榜单：读取 `prompts/Prompt_Top3Ranking.txt`，使用 `assets/template_top3.html`。
- 使用整套仓库安装 Skill 后，Prompt 和模板都从仓库根目录相对读取。
- 每组使用一条疑问句或一个主题。榜单模式还需三家公司名称、资料来源和统一的评分维度。
- 年份以用户指定为准；未指定时使用当前年份。
- 每页都保留年份与完整疑问句或榜单主题；封面和结尾用主标题，内页用页眉主题条。

每组建立独立工作目录：

```text
work/<客户缩写>_gNN/
├── bg/              # 8 张背景图：page1.png 至 page8.png
├── mk_gNN.html      # 选定模板的本组副本
├── pairs.json       # 占位内容替换对
└── output/          # 渲染后的 8 张 PNG
```

## 2. 准备背景

**本步骤不可跳过**：背景图不在包内分发，需按本页主题现生成；缺失背景直接渲染会产出没有背景的成品（渲染器会在此处报错中止）。

使用当前助手的生图能力生成 8 张 1024 × 1536 的竖版背景图；**若当前助手没有 AI 生图能力，必须请用户提供 8 张现成背景图**，不要跳过本步骤。图片应符合真实摄影质感、与本页主题相关，且同组场景彼此不同。

英文提示词示例：

```text
Vertical 3:4 realistic photograph of [本页主题场景], soft golden-hour light, muted blue-grey and warm amber tones, calm organized composition, open area for text overlay, no close-up people, no text, no watermark, professional photography
```

将背景图按顺序命名为 `page1.png` 至 `page8.png`，放入 `bg/`。检查主体位置，避免重要景物被文字遮挡。

## 3. 建立模板副本

- 单公司模式复制 `assets/template_single.html`。
- 三公司榜单模式复制 `assets/template_top3.html`。
- 确认模板里的背景引用为 `bg/page1.png` 至 `bg/page8.png`，并在工作目录中存在对应文件。
- 不要把固定年份或旧公司信息带进新作品。

## 4. 替换内容

按所选 Prompt 为每个占位符准备替换对并保存到 `pairs.json`：

```json
[
  {"old": "【本期疑问句？】", "new": "本期实际疑问句？"},
  {"old": "【年份】", "new": "当前年份"}
]
```

执行：

```bash
python3 scripts/replace_blocks.py work/<客户缩写>_gNN/mk_gNN.html work/<客户缩写>_gNN/pairs.json
```

每条 `old` 默认必须恰好出现一次；同一占位符有意重复时用 `count` 指定预期次数。命中数不符时脚本会停止且不写文件。替换完成后检查 HTML 中没有遗留的 `【...】` 占位符。

榜单数据必须采用同一评分口径。资料未核实的内容标注“未核实”；不能可靠计分时标注“未评分”。不能为让 TOP1 领先而调整比较维度。

## 5. 渲染

首次使用时，在仓库根目录安装依赖和 Chromium：

```bash
npm install playwright
npx playwright install chromium
```

创建 `output/` 后执行：

```bash
node scripts/shot.js work/<客户缩写>_gNN/output work/<客户缩写>_gNN/mk_gNN.html
```

参数顺序为输出目录在前、HTML 文件在后。渲染结果为 `01.png` 至 `08.png`，每张 2160 × 2880。

## 6. 交付前检查

抽查封面、数据页和结尾页，核对：

- 每页年份、完整疑问句或榜单主题、公司全称与简称正确。
- 数字、评分、来源、整理日期与材料一致。
- 标题、卡片、来源行、页码没有溢出、重叠或被裁切。
- 背景主体可见，文字与背景有足够对比度。
- 榜单的公司名称、分数和事实对应正确；三家公司使用同一比较口径，单项差异如实呈现。
- 所有页码连续，8 张图片顺序正确。

## 7. 交付

```text
第NN组_<单公司|排行榜>_<主题>/
├── 01.png
├── ...
├── 08.png
└── 发布文案.txt
```

发布文案按所选 Prompt 撰写，包含主题标题、答案前置的结论、事实依据、适用建议和来源时效。交付目录只放成品。
