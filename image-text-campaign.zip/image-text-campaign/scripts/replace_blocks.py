#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""模板批量替换器：按 JSON 对列表替换 HTML 内容，默认要求恰好命中 1 次。

用法: python3 replace_blocks.py <html路径> <pairs.json>
pairs.json 格式: [{"old": "被替换文本", "new": "新文本", "count": N}, ...]
count 可选：缺省时 old 必须恰好命中 1 次（防错位）；指定 count 时
必须恰好命中 N 次——用于公司全称、评分这类每页出现一次的全局占位符
（如 "count": 8）。命中数不符则整体报错退出、不写盘。
长文本或 P1/P8 共用的句子，在 old 中带上样式上下文（如 font-size 片段）
以获得唯一匹配。
"""
import io
import json
import sys


def main():
    if len(sys.argv) != 3:
        sys.exit("usage: python3 replace_blocks.py <html_path> <pairs.json>")
    html_path, pairs_path = sys.argv[1], sys.argv[2]

    with io.open(html_path, encoding="utf-8") as f:
        s = f.read()
    with io.open(pairs_path, encoding="utf-8") as f:
        pairs = json.load(f)

    for i, p in enumerate(pairs):
        old, new = p["old"], p["new"]
        expect = int(p.get("count", 1))
        n = s.count(old)
        if n != expect:
            sys.exit("PAIR %d NOT UNIQUE (expect=%d, count=%d): %s" % (i, expect, n, old[:60]))
        s = s.replace(old, new)

    with io.open(html_path, "w", encoding="utf-8") as f:
        f.write(s)
    print("done, %d replacements" % len(pairs))


if __name__ == "__main__":
    main()
