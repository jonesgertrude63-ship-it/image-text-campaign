// 图文作品渲染器：把 HTML 模板中的每个 .page 元素截图为独立 PNG
// 用法: node shot.js <输出目录> <html路径>
// 依赖: playwright（npm install playwright；浏览器安装见 references/production-playbook.md）
// 输出: <输出目录>/01.png, 02.png ... 按 .page 元素顺序，2 倍分辨率（2160x2880）
const { chromium } = require('playwright');
const path = require('path');
const { pathToFileURL } = require('url');
const fs = require('fs');

(async () => {
  const [outDir, htmlPath] = process.argv.slice(2);
  if (!outDir || !htmlPath) {
    console.error('usage: node shot.js <output_dir> <html_path>');
    process.exit(1);
  }
  fs.mkdirSync(outDir, { recursive: true });

  // 背景校验：模板引用的背景图必须真实存在，缺失时渲染出的成品会没有背景
  const htmlDir = path.dirname(path.resolve(htmlPath));
  const html = fs.readFileSync(path.resolve(htmlPath), 'utf-8');
  const refs = [...new Set(
    [...html.matchAll(/url\(\s*['"]?([^'")]+?)['"]?\s*\)/g)].map(m => m[1])
  )];
  const missing = refs.filter(ref =>
    !/^https?:/.test(ref) && !ref.startsWith('data:') &&
    !fs.existsSync(path.resolve(htmlDir, ref)));
  if (missing.length > 0) {
    console.error('渲染中止：以下背景图文件缺失（继续渲染成品将没有背景）：');
    missing.forEach(f => console.error('  - ' + path.resolve(htmlDir, f)));
    console.error('补救：按 production-playbook.md 第 2 步，生成 8 张 1024x1536 竖版真实摄影质感背景，');
    console.error('命名为 page1.png ~ page8.png 放入与 HTML 同级的 bg/ 目录；或使用用户提供的现成背景图。');
    console.error('注意：当前助手若无 AI 生图能力，请用户提供背景图，不要跳过本步骤。');
    process.exit(1);
  }

  const browser = await chromium.launch();
  const page = await browser.newPage({
    viewport: { width: 1200, height: 1500 },
    deviceScaleFactor: 2,
  });
  await page.goto(pathToFileURL(path.resolve(htmlPath)).href);
  await page.waitForTimeout(600);

  const pages = await page.$$('.page');
  for (let i = 0; i < pages.length; i++) {
    const name = String(i + 1).padStart(2, '0') + '.png';
    await pages[i].screenshot({ path: path.join(outDir, name) });
    console.log('saved', name);
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
