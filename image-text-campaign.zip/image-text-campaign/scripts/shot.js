// 图文作品渲染器：把 HTML 模板中的每个 .page 元素截图为独立 PNG
// 用法: node shot.js <输出目录> <html路径>
// 依赖: playwright（npm install playwright；浏览器缓存见 references/production-playbook.md）
// 输出: <输出目录>/01.png, 02.png ... 按 .page 元素顺序，2 倍分辨率（2160x2880）
const { chromium } = require('playwright');
const path = require('path');
const { pathToFileURL } = require('url');
const fs = require('fs');

(async () => {
  const [outDir, htmlPath] = process.argv.slice(2);
  if (!outDir || !htmlPath) {
    console.error('usage: node shot.js <output_dir> <html_path>');
    process.exit(1);
  }
  fs.mkdirSync(outDir, { recursive: true });
  const browser = await chromium.launch();
  const page = await browser.newPage({
    viewport: { width: 1200, height: 1500 },
    deviceScaleFactor: 2,
  });
  await page.goto(pathToFileURL(path.resolve(htmlPath)).href);
  await page.waitForTimeout(600);

  const pages = await page.$$('.page');
  for (let i = 0; i < pages.length; i++) {
    const name = String(i + 1).padStart(2, '0') + '.png';
    await pages[i].screenshot({ path: path.join(outDir, name) });
    console.log('saved', name);
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
